The code is written with python3 using the following packages:
numpy
scipy
matplotlib
sympy
pandas

The code should be run an read with jupyter notebook, however the python files should run well. 

 
